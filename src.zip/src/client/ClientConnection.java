package client;

import java.io.IOException;

import javax.swing.JOptionPane;

import com.esotericsoftware.kryonet.Client;
import com.esotericsoftware.kryonet.Connection;
import com.esotericsoftware.kryonet.Listener;

import communication.AuxCom;
import communication.ClassRegister;
import communication.LoginComR;
import communication.SignupComR;

public class ClientConnection {

	Client client;
	ClientMain clma;
	
	public ClientConnection(ClientMain cm) {
		clma = cm;
	}
	
	public Client generateConnection(String hIP) {
		createClient(hIP);
		clAddListener(); 
		return client;
	}
	
	private void createClient(String hIP) {
		client = new Client();
		ClassRegister.register(client);
	    client.start();
	    try {
			client.connect(5000, hIP, 54555, 54777);
		} catch (IOException e) {
			e.printStackTrace();
		}    
	}

	private void clAddListener() {
		client.addListener(new Listener() {
		       public void received (Connection connection, Object object) {
		          if(object instanceof LoginComR) {
		        	  LoginComR resp = (LoginComR)object;
		        	  clma.attemptLoginR(resp.ID);
		          }
		          
		          if(object instanceof SignupComR) {
		        	  SignupComR resp = (SignupComR)object;
		        	  clma.attemptSignupR(resp.ID);
		          }
		          if(object instanceof Object[] || object instanceof String[]) {
		        	  Object[] resp = (Object[])object;
		        	  clma.receiveInsert(resp);
		          }
		          if(object instanceof AuxCom) {
		        	  AuxCom resp = (AuxCom)object;
		        	  if(resp.id == -1) {
		        		  JOptionPane.showMessageDialog(null, "Database Error", "Error", JOptionPane.ERROR_MESSAGE);
		        	  }
		        	  if(resp.id == 0)
		        		  clma.refreshTable();
		        	  if(resp.id == 1)
		        		  clma.deleteItemR();
		          }
		          
		       }
		       public void disconnected(Connection connection) {
		    	   System.exit(0);
		       }
		       
		    });
	}
}
