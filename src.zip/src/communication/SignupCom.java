package communication;

public class SignupCom {
	public String user;
	public String pass;
	
	public SignupCom() {
		user = "";
		pass = "";
	}
	
	public SignupCom(String u, String p) {
		user = u;
		pass = p;
	}
}
