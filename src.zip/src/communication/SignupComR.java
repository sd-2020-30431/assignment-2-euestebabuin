package communication;

public class SignupComR {
	public int ID;
	
	public SignupComR()
	{
		ID = -1;
	}
	
	public SignupComR(int id)
	{
		ID = id;
	}
}
