package database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class QuerySignup {
	
	String username;
	String password;
	public QuerySignup(String user, String pass){
		password = pass;
		username = user;
	}
	
	public boolean unique() throws Exception{
		Connection dbc = ConnectR.getConnection();
		PreparedStatement st = null;
		ResultSet rs = null;
		
		st = dbc.prepareStatement("Select * from client where user = '" + username + "';");
		rs = st.executeQuery();
		boolean rez = !rs.next();
		

		ConnectR.close(dbc);
		ConnectR.close(st);
		ConnectR.close(rs);
		
		return rez;
	}
	
	public boolean register() throws SQLException {
		Connection dbc = ConnectR.getConnection();
		PreparedStatement st = null;
			st = dbc.prepareStatement("Insert into client (user,pass) values ('" + 
			username + "','" + password + "');");
			st.executeUpdate();
		ConnectR.close(dbc);
		return true;
	}
}
