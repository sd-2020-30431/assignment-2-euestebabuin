package client;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;


public class Login {
	
	JTextField user;
	JPasswordField pass;
	JFrame fr;
	ClientMain clientM;
	
	Login(ClientMain sm){
		clientM = sm;
		initGUI();
	}

	
	private void initGUI() {

		user = new JTextField(15);
		pass = new JPasswordField(15);
		
		fr = new JFrame("Login to Wasteless");		
		fr.setContentPane(makeTextBoxes());
		fr.setSize(300, 170);
		fr.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		fr.setVisible(true);
	}

	
	JPanel makeTextBoxes() {
		JPanel jp = new JPanel();
		jp.setLayout(new BoxLayout(jp, BoxLayout.Y_AXIS));
			
		JPanel pan0 = new JPanel();
		JLabel welcome = new JLabel("Welcome to Wasteless");
		pan0.add(welcome);
		welcome.setAlignmentX(JLabel.CENTER_ALIGNMENT);
		jp.add(pan0);
		
		JPanel pan1 = new JPanel();
		pan1.add(new JLabel("Username:"));	
		pan1.add(user);
		jp.add(pan1);
		
		JPanel pan2 = new JPanel();
		pan2.add(new JLabel("Password:"));
		pass.setEchoChar('�');
		pan2.add(pass);
		jp.add(pan2);
		
		JPanel pan3 = new JPanel();
		JButton login = new JButton("Login");
		JButton signup = new JButton("Signup");
		login.addActionListener(new ClickLogin());
		signup.addActionListener(new ClickSignup());
		pan3.add(login);
		pan3.add(signup);
		login.setAlignmentX(JButton.CENTER_ALIGNMENT);
		signup.setAlignmentX(JButton.CENTER_ALIGNMENT);
		jp.add(pan3);
		
		return jp;
	}
	
	private class ClickLogin implements ActionListener{
    	ClickLogin(){}
		public void actionPerformed(ActionEvent arg0) {
			try {
				clientM.attemptLogin(user.getText(), pass.getText());
			}
			catch(Exception e) {
				JOptionPane.showMessageDialog(null, "Database connenction error", "Error", JOptionPane.ERROR_MESSAGE);
			} 
		}
		
    }
	
	public void LoginResponse(int userID) {
		if(userID != -1) {
			fr.setVisible(false);
			clientM.nextUI();
		}
		else
			JOptionPane.showMessageDialog(null, "Invalid login attempt", "Error", JOptionPane.ERROR_MESSAGE);
	}
	
	private class ClickSignup implements ActionListener{
    	ClickSignup(){}
		public void actionPerformed(ActionEvent arg0) {
			if(!clientM.attemptSignup(user.getText(), pass.getText()))
				JOptionPane.showMessageDialog(null, "Username[min 5] or password[min 8] too short. ",
						"Error", JOptionPane.WARNING_MESSAGE);
		}
    }
	
	public void SignupResponse(int state) {
		if(state == -1) {
			JOptionPane.showMessageDialog(null, "Couldn't register, database Error", "Error", JOptionPane.ERROR_MESSAGE);
		}
		if(state == 0) {
			JOptionPane.showMessageDialog(null, "Username already taken", "Error", JOptionPane.ERROR_MESSAGE);
		}
		if(state == 1) {
			JOptionPane.showMessageDialog(null, "Successfully registered", "Done", JOptionPane.INFORMATION_MESSAGE);
		}
	}

}
