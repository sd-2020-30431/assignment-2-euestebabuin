package server;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import com.esotericsoftware.kryonet.Server;

public class ServerUI {
	
	JFrame frame;
	JTextArea jta;
	Server server;
	
	public ServerUI(Server s) {
		server = s;
		initUI();
	}
	
	private void initUI() {
		frame = new JFrame("Server Log");
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.addWindowListener(new WindowAdapter() {
			public void windowClosed (WindowEvent evt) {
				server.stop();
			}
		});
		jta = new JTextArea(40, 5);
		JScrollPane jsp = new JScrollPane(jta);
		frame.setContentPane(jsp);
		frame.setSize(370, 200);
		frame.setVisible(true);
	}
	public void addLog(String s) {
		jta.setText(jta.getText() + s + System.lineSeparator());
	}
}
