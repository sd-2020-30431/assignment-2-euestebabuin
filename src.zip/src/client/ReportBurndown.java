package client;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Observable;

public class ReportBurndown extends Observable {
	private ArrayList<Object[]> data;
	private static final long toDays = 1000 * 3600 * 24;
	
	public ReportBurndown(ArrayList<Object[]> _data, ClientMain cm) {
		data = _data;
		this.addObserver(cm);
	}
	
	public ReportBurndown(ArrayList<Object[]> _data) {
		data = _data;
	}
	
	public int getBDR() {
		int today_bdr = 0;
		DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
		ArrayList<String> expires_tomorow = new ArrayList<String>();
		for(int i = 0; i < data.size(); i++) {
			long todaymil = new Date().getTime();
			long productmil = 0;
			try {productmil = dateFormat.parse((String)data.get(i)[4]).getTime();}
			catch(Exception e) {e.printStackTrace();}
			float days_to_expire = ((productmil - todaymil)/(1.0f * toDays));
			if(days_to_expire > 0) {
				today_bdr += (int)data.get(i)[1] * (int)data.get(i)[2] / days_to_expire;
			}
			if(days_to_expire >= 0.1 && days_to_expire <= 1.1) {
				expires_tomorow.add((String)data.get(i)[0]);
			}
		}
		if(expires_tomorow.size() != 0) {
			this.setChanged();
			this.notifyObservers(expires_tomorow);
		}
		return today_bdr;
	}
	
	public ArrayList<Object[]> createReport(ArrayList<Object[]> data, int days) {
		ArrayList<Object[]> newData = new ArrayList<Object[]>();
		DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
		for(int i = 0; i < data.size(); i++) {
			long todaymil = new Date().getTime();
			long productmil = 0;
			try {productmil = dateFormat.parse((String)data.get(i)[4]).getTime();}
			catch(Exception e) {e.printStackTrace();}
			int days_since_expired = (int)((todaymil - productmil)/toDays);
			if(days_since_expired > 0 && days_since_expired < days) {
				newData.add(data.get(i));
			}
		}
		return newData;
	}
}
