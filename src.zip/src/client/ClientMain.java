package client;

import java.util.ArrayList;
import java.util.Observable;
import java.util.Observer;

import javax.swing.JOptionPane;

import com.esotericsoftware.kryonet.Client;

import communication.AuxCom;
import communication.LoginCom;
import communication.SignupCom;

public class ClientMain implements Observer {
	
	Client client; // the connection to the server
	Login log; // firstUI
	MainGUI mg; //second UI
	int userID, itemToDelete; //user's Id in database and item to be deleted/ subtracted quantity
	Valid valid; //validation class
	private ArrayList<Object[]> data; //data of application
	boolean first_time, report_mode; //first_time ensures the burdown notif appears once
										//certain functions are disabled in report mode

	
	public ClientMain(String hIP) {
		ClientConnection cc = new ClientConnection(this);
		client = cc.generateConnection(hIP);
		log = new Login(this);
		userID = -1;
		valid = new Valid();
		data = new ArrayList<Object[]>();
		first_time = true;
		report_mode = false;
	}
	//login functions, question and repsonse
	public void attemptLogin(String user, String pass) {
			client.sendTCP(new LoginCom(user, pass));	    
	}
	
	public void attemptLoginR(int uID) {
		userID = uID;
		log.LoginResponse(uID);
	}
	//signup functions, question and repsonse
	public boolean attemptSignup(String user, String pass) {
		if(valid.validateLogin(user, pass)) {
			client.sendTCP(new SignupCom(user, pass));
			return true;
		}
		else
			return false;
	}
	
	public void attemptSignupR(int state) {
		log.SignupResponse(state);
	}
	//Login complete
	public void nextUI() {		
		mg = new MainGUI(this);
	}
	//retrieving client's items
	public void getTableData() {
		data.clear();
		client.sendTCP(new AuxCom(-1, userID));
	}

	public void refreshTable() {
		mg.refreshTable(data);
		this.checkBurnDown(first_time);
		first_time = false;
	}
	
	public void deleteItem(int itemId) {
		itemToDelete = itemId;
		client.sendTCP(new AuxCom((int) (data.get(itemId))[5]));
	}
	//deleting one item at a time (also 1 quantity at a time)
	public void deleteItemR() {
		int quantity = (int)data.get(itemToDelete)[1];
		if(quantity > 1) {
			quantity--;
			data.get(itemToDelete)[1] = quantity;
		}
		else
			data.remove(itemToDelete);
		itemToDelete = -1;
		this.refreshTable();
	}
	
	public void insert(String item[]) {
		if(valid.validateData(item)) {
			client.sendTCP((Object[])item);
		}
	}
	
	public void receiveInsert(Object item[]) {
		data.add(item);
	}
	
	int getUserID() {
		return userID;
	}
	
	boolean getReportMode() {
		return report_mode;
	}
	
	public static void main(String[] args) {
		new ClientMain("192.168.1.61"); //host's ip
	}
	//Calculating the burndown rate and taking action if itis too high
	public void checkBurnDown(boolean show) {
		ReportBurndown rb = new ReportBurndown(data, this);
		int today_bdr = rb.getBDR();
		if(today_bdr > 2000) {
			if(show)
			JOptionPane.showMessageDialog(null, "Warning, today's ideal burning rate is too high " + today_bdr,
					"Imminent Waste!", JOptionPane.WARNING_MESSAGE);
			mg.colorDonate('r');
		}
		else {
			if(show)
			JOptionPane.showMessageDialog(null, "Today's ideal burning rate: " + today_bdr, "Welcome!",
					JOptionPane.INFORMATION_MESSAGE);
			mg.colorDonate('a');
		}
	}
	
	public void reportModeDisable() {
		report_mode = false;
	}
	
	public void showReport(int days) {
		report_mode = true;
		ReportBurndown rb = new ReportBurndown(data);
		ArrayList<Object[]> report = rb.createReport(data, days);
		mg.refreshTable(report);
	}
	//the observer is notified if an item is due to expire
	@Override
	public void update(Observable o, Object arg) {
		if(first_time == true) {
			ArrayList<String> et = (ArrayList<String>)arg;
			String warning = "Warning, the following items will expire tomorow: ";
			for(String s : et)
				warning += s + " ";
			JOptionPane.showMessageDialog(null, warning + "!",
					"Imminent Waste!", JOptionPane.WARNING_MESSAGE);
		}
	}
	
}
