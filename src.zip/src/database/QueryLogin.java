package database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class QueryLogin {
	
	String query;
	String password;
	Connection dbc = ConnectR.getConnection();
	public QueryLogin(String user, String pass){
		password = pass;
		query = "Select pass,id from client where user = '" + user +"';";
	}
	
	public int loginCheck(){
		PreparedStatement st = null;
		
		try {
			st = dbc.prepareStatement(query);
			return getUserID(st.executeQuery());
		} catch (SQLException e) {
			e.printStackTrace();
		}	
		return -2;
	}
	
	private int getUserID(ResultSet rs) {
		int id = -1;
		try {
			if(!rs.next()) {
				return -1;	
				}
			else
			{	
				String pass = rs.getString("pass");
				if(pass.compareTo(password) != 0)
					return -1;
				id = rs.getInt("id");
			}
		}
		catch(SQLException e) {
			System.out.println("SQL Exception");
			e.printStackTrace();
		}
		return id;
	}
}
