package communication;

public class LoginCom {
	public String user;
	public String pass;
	
	public LoginCom() {
		user = "";
		pass = "";
	}
	
	public LoginCom(String u, String p) {
		user = u;
		pass = p;
	}
}
