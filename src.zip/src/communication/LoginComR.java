package communication;

public class LoginComR {
	public int ID;
	
	public LoginComR()
	{
		ID = -1;
	}
	
	public LoginComR(int id)
	{
		ID = id;
	}
}
