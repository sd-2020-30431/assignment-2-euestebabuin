package server;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.esotericsoftware.kryonet.Connection;
import com.esotericsoftware.kryonet.Server;

import communication.AuxCom;
import communication.LoginComR;
import communication.SignupComR;
import database.QueryUpdate;
import database.QueryGetItems;
import database.QueryLogin;
import database.QuerySignup;

public class ServerMain {
	private Server server; //the connection
	ServerUI sui; //the minimalist log
	
	public ServerMain(int tcp, int udp) {
		ServerConnection sc = new ServerConnection();
		server = sc.createServer(tcp, udp, this);
		sui = new ServerUI(server);
	}
	
	public void addLog(String s) {
		sui.addLog(s);
	}
	
	public void responseLogin(String u, String p, Connection c) {
		QueryLogin ql = new QueryLogin(u, p);
		int uid = ql.loginCheck();
		if(uid == -2)
			addLog("Database error");
		else {
			addLog("Client authenticated");
			c.sendTCP(new LoginComR(uid));
		}
		
	}
	
	public void responseSignup(String u, String p, Connection c) {
		QuerySignup qs = new QuerySignup(u,p);
		int state = -1;
		try {
			if (qs.unique()) {
				if(qs.register())
					state = 1;
			}
			else
				state = 0;
		}catch(Exception e){
			state = -1;
		}
		c.sendTCP(new SignupComR(state));
	}
	//retrieve an client's items
	public void getTableData(Connection c, int userID) {
		QueryGetItems qgi = new QueryGetItems();
		Object data[][] = qgi.getItems(userID);
		for(int i = 0; i < data.length; i++)
			c.sendTCP(data[i]);
		c.sendTCP(new AuxCom(0));
	}
	//deleting/subtracting quantity from an item
	public void removeItem(int id, Connection c) {
		QueryGetItems qgi = new QueryGetItems();
		Object data[] = qgi.getItemid(id);
		int quantity = (int)data[1];
		String query;
		QueryUpdate qao = new QueryUpdate();
		if(quantity == 1) 
			query = "Delete from groceries where id = " + id + ";";
		else
			query = "Update groceries set quantity = " + --quantity + " where id = " + id;
		
		qao.update(query);
		c.sendTCP(new AuxCom(1)); //refresh local client table
	}
	//Adding an item and the sending the client's the item, so he can also add it locally
	//if the database operation is successful. The item is retrieved from the database
	//as soon it is introduced so the client knows the item's id in the databse
	public void addItem(String newobj[], Connection c) {
		QueryUpdate qao = new QueryUpdate();
		DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
		Date date = new Date();
		String query = "Insert into groceries (id_client, name, quantity, kcal, buydate, expdate) values (" +
				newobj[4] + ",'" + newobj[0] + "'," + newobj[1] + "," + newobj[2] + ",'" + dateFormat.format(date)+"','" + newobj[3] + "');";
		qao.update(query);
		QueryGetItems qgi = new QueryGetItems();
		Object data[] = qgi.getItem(newobj[4]);
		c.sendTCP(data);
		c.sendTCP(new AuxCom(0)); //refresh local client table
	}
	
	public static void main(String[] args) {
		new ServerMain(54555, 54777); //tcp and udp port
		
	}

}
