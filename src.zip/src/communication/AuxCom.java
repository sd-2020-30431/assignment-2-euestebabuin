package communication;

public class AuxCom {

	public int id;
	public int userID;
	/*When sent from client to server:
	 * id == -1, get all products from database
	 * 
	 * id >= 0, delete product with id
	 * When sent from server to client:
	 * id == -1 operation unsuccessful
	 * id == 0 all items retrieved, can refresh table
	 * id == 1 item deleted, can delete from local client data
	 * */
	 
	
	public AuxCom() {
		id = -1;
	}
	
	public AuxCom(int _id) {
		id = _id;
	}
	public AuxCom(int _id, int _userID) {
		id = _id;
		userID = _userID;
	}
}
