package client;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;




public class MainGUI  {
	ClientMain cm;
	JTable tab;
	String columnNames[] = {"Name", "Quantity", "Kcal", "Buy Date", "Expiration Date"};
	JTextField name,quantity,kcal,expDate;
	JButton donate;
	public MainGUI(ClientMain _cm) {
		cm = _cm;
		initGUI();
		cm.getTableData();
	}
	
	public void refreshTable(ArrayList<Object[]> data) {

		System.out.println("ok");
		TableModel tableModel = new DefaultTableModel(columnNames, data.size());
		tab.setModel(tableModel);
		for(int i = 0;i < data.size(); i++)
			for(int j = 0; j < 5; j++) {
				tab.setValueAt(data.get(i)[j], i, j);
			}	
		System.out.println("ok");
	}
	
	
	private void initGUI() {
		JFrame fr = new JFrame("WasteLess");
		JPanel jp = new JPanel();
		jp.setAlignmentX(0);
		
		jp.add(createTable());
		jp.add(createOthers());
		
		fr.setContentPane(jp);
		fr.setSize(550, 320);
		fr.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		jp.setLayout(new BoxLayout(jp, BoxLayout.Y_AXIS));
		fr.setVisible(true);
	}
	
	private JScrollPane createTable() {
		Object data[][] = {{"Pizza", new Integer(5), new Integer(200), "lalala", "05/04/2020"}};
		tab = new JTable(data, columnNames);

		JScrollPane jsc = new JScrollPane(tab);
		tab.setFillsViewportHeight(true);
		return jsc;
	}
	private JPanel createOthers() {
		JPanel jp = new JPanel();
		jp.setLayout(new GridLayout());
		jp.setMinimumSize(new Dimension(310,140));
		jp.setAlignmentX(0);
		
		JButton eat = new JButton("Eat");
		eat.addActionListener(new Click());
		jp.add(eat);
		
		jp.add(createAdd());
		jp.add(createReports());
		return jp;
	}
	
	private JPanel createReports() {
		JPanel jp = new JPanel();
		JButton weekRep = new JButton("View last week's report");
		weekRep.addActionListener(new Click());
		jp.add(weekRep);
		JButton monthRep = new JButton("View last month's report");
		monthRep.addActionListener(new Click());
		jp.add(monthRep);
		donate = new JButton("Donate");
		donate.addActionListener(new Click());
		jp.add(donate);
		JButton all = new JButton("View All");
		all.addActionListener(new Click());
		jp.add(all);
		return jp;
	}
	private JPanel createAdd() {
		JPanel jp = new JPanel();
		name = new JTextField("Name                 ");
		name.addMouseListener(new MouseList());
		jp.add(name);
		quantity = new JTextField("Quantity");
		quantity.addMouseListener(new MouseList());
		jp.add(quantity);
		kcal = new JTextField("Kcal       ");
		kcal.addMouseListener(new MouseList());
		jp.add(kcal);
		expDate = new JTextField("Expiration Date");
		expDate.addMouseListener(new MouseList());
		jp.add(expDate);
		JButton add = new JButton("Add to fridge");
		add.addActionListener(new Click());
		jp.add(add);
		return jp;
	}
	//addMouseListener(new 
	private class MouseList implements MouseListener
	{
		@Override
		public void mouseClicked(MouseEvent e){
			((JTextField)e.getComponent()).setText("");
		}

		@Override
		public void mouseEntered(MouseEvent arg0) {}

		@Override
		public void mouseExited(MouseEvent arg0) {}

		@Override
		public void mousePressed(MouseEvent arg0) {}

		@Override
		public void mouseReleased(MouseEvent arg0) {}
    };
    
    private class Click implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			boolean rm = cm.getReportMode(); // in report mode certain operations are unavailable
			if(((JButton)(e.getSource())).getText().compareTo("Eat") == 0 && !rm) {
				if(tab.getSelectedRow() != -1) {
					cm.deleteItem(tab.getSelectedRow());
					cm.checkBurnDown(false);
				}
		}
			if(((JButton)(e.getSource())).getText().compareTo("Add to fridge") == 0 && !rm)
			{
				String newobj[] = {name.getText(), quantity.getText(),
						kcal.getText(), expDate.getText(), "" + cm.getUserID()};
				cm.insert(newobj);
			}
			if(((JButton)(e.getSource())).getText().compareTo("View last week's report") == 0)
				cm.showReport(7);
			if(((JButton)(e.getSource())).getText().compareTo("View last month's report") == 0)
				cm.showReport(31);
			if(((JButton)(e.getSource())).getText().compareTo("Donate") == 0 && !rm) {
				if(tab.getSelectedRow() != -1) {
					cm.deleteItem(tab.getSelectedRow());
					cm.checkBurnDown(false);
				}
			}
			if(((JButton)(e.getSource())).getText().compareTo("View All") == 0) {
				cm.reportModeDisable();
				cm.refreshTable();
			}
		}
		
    }
    
    public void colorDonate(char c) {
    	if(c == 'r')
    		donate.setBackground(new Color(255, 0, 0));
    	else
    		donate.setBackground(new Color (221,232,243));
    }
}
