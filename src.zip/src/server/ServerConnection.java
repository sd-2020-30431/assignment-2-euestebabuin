package server;

import java.io.IOException;
import java.net.InetSocketAddress;

import com.esotericsoftware.kryonet.Connection;
import com.esotericsoftware.kryonet.Listener;
import com.esotericsoftware.kryonet.Server;

import communication.ClassRegister;
import communication.AuxCom;
import communication.LoginCom;
import communication.SignupCom;

public class ServerConnection {

	Server server;
	ServerMain servma;
	
	public Server createServer(int tcp, int udp, ServerMain sm) {
		servma = sm;
		serverBind(tcp, udp);
		svAddListener();
		return server;
	}
	
	private void serverBind(int tcp, int udp) {
		server = new Server();
		ClassRegister.register(server);
	    server.start();
	    try {
			server.bind(tcp, udp);
		} catch (IOException e) {
			e.printStackTrace();
			
		}
	    

	}
	
	private void svAddListener() {
		server.addListener(new Listener() {
		       public void received (Connection connection, Object object) {
		    	   String clientIP = connection.getRemoteAddressTCP().toString();
		          if (object instanceof LoginCom) {
		             LoginCom mesg = (LoginCom)object;
		             
		             servma.addLog("A client tries to login with:");
		             servma.addLog("USER: " + mesg.user + " PASS: " + mesg.pass);
		             servma.responseLogin(mesg.user, mesg.pass, connection);
		          }
		          if (object instanceof SignupCom) {
		        	  SignupCom mesg = (SignupCom)object;
			             
			             servma.addLog("A client tries to signup with:");
			             servma.addLog("USER: " + mesg.user + " PASS: " + mesg.pass);
			             servma.responseSignup(mesg.user, mesg.pass, connection);
			          }
		          
		          if (object instanceof String[]) {
		        	  String[] mesg = (String[])object;		             
			             servma.addLog("A client tries to add item to list: " + clientIP);
			             servma.addItem(mesg, connection);
			          }
		          
		          if (object instanceof AuxCom) {
		        	  AuxCom mesg = (AuxCom)object;
			             if(mesg.id == -1) {
			            	 servma.getTableData(connection, mesg.userID);
				             servma.addLog("Retrieving data for client: " + clientIP);
				             servma.addLog("Client ID in database: " + mesg.userID);
			             }
			             else {
			            	 servma.removeItem(mesg.id, connection);
				             servma.addLog("Deleting item with id: " + mesg.id +
				            		 " for client "+ clientIP);
			             }
			          }
		       }
		       public void connected(Connection connection) {
		    	   InetSocketAddress inet = connection.getRemoteAddressTCP();
		    	   servma.addLog("A client has connected to the server : " +inet);
		       }
		       public void disconnected(Connection connection) {
		    	   servma.addLog("A client has disconnected from the server");
		       }
		    });
	}
	
}
