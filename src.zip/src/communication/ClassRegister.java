package communication;

import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryonet.EndPoint;

public class ClassRegister {

	static public void register (EndPoint endPoint) {
		Kryo kryo = endPoint.getKryo();
		kryo.register(LoginCom.class);
		kryo.register(LoginComR.class);
		kryo.register(SignupCom.class);
		kryo.register(SignupComR.class);
		kryo.register(Object[].class);
		kryo.register(String[].class);
		kryo.register(AuxCom.class);
	}
}
